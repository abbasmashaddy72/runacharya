<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo e($dark_mode ? 'dark' : ''); ?>">

<head>
    <?php echo e(Vite::useBuildDirectory('/backendAssets')); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="<?php echo e(asset('dist/images/logo.svg')); ?>" rel="shortcut icon" type="image/svg+xml">
    <title>
        <?php if(!empty($title)): ?>
            <?php echo e($title . ' | '); ?><?php echo e(config('app.name', 'Laravel')); ?>

        <?php else: ?>
            <?php echo e(config('app.name', 'Laravel')); ?>

        <?php endif; ?>
    </title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/backend/app.css', 'resources/js/backend/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo \Rawilk\FormComponents\Facades\FormComponents::outputStyles(); ?>
</head>

<body class="login">

    <div class="container sm:px-10">
        <div class="block grid-cols-2 gap-4 xl:grid">
            <!-- BEGIN: Login Info -->
            <div class="flex-col hidden min-h-screen xl:flex">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['class' => 'items-center pt-5 -intro-x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'items-center pt-5 -intro-x']); ?>
                    <span class="ml-3 text-lg text-white">
                        <?php echo e(config('app.name', 'Laravel')); ?>

                    </span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="my-auto">
                    <?php echo e($left); ?>

                </div>
            </div>
            <!-- END: Login Info -->
            <div class="flex h-screen py-5 my-10 xl:h-auto xl:py-0 xl:my-0">
                <div
                    class="w-full px-5 py-8 mx-auto my-auto bg-white rounded-md shadow-md xl:ml-20 dark:bg-darkmode-600 xl:bg-transparent sm:px-8 xl:p-0 xl:shadow-none sm:w-3/4 lg:w-2/4 xl:w-auto">
                    <?php echo e($right); ?>

                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.bePartials.dark-mode-switch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo \Rawilk\FormComponents\Facades\FormComponents::outputScripts(); ?>
</body>

</html>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/layouts/guest.blade.php ENDPATH**/ ?>