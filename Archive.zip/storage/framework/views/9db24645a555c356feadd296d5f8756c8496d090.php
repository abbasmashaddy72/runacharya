<div class="<?php echo e($getContainerClass()); ?>">
    <?php echo $__env->make('form-components::partials.leading-addons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <select <?php if($name): ?> name="<?php echo e($name); ?>" <?php endif; ?>
            <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?>
            <?php if($multiple): ?> multiple <?php endif; ?>
            <?php echo $ariaDescribedBy(); ?>

            <?php echo e($extraAttributes); ?>


            <?php if($hasErrorsAndShow($name)): ?>
                aria-invalid="true"
            <?php endif; ?>

            <?php echo e($attributes->class($inputClass())); ?>

    >
        <?php echo e($slot); ?>


        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php if($isSelected($key)): ?> selected <?php endif; ?>>
                <?php echo e($label); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($append ?? ''); ?>

    </select>

    <?php echo $__env->make('form-components::partials.trailing-addons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/vendor/form-components/components/inputs/select.blade.php ENDPATH**/ ?>