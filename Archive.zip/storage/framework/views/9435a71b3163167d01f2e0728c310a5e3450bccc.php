<?php if($leadingAddon): ?>
    <span class="leading-addon inline-flex items-center px-3 rounded-l-md border border-r-0 border-slate-300 bg-slate-50 text-slate-500 sm:text-sm">
        <span class="text-slate-400">
            <?php echo $leadingAddon; ?>

        </span>
    </span>
<?php elseif($inlineAddon): ?>
    <div class="inline-addon absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
        <span class="text-slate-500 sm:text-sm sm:leading-5"><?php echo $inlineAddon; ?></span>
    </div>
<?php elseif($leadingIcon): ?>
    <div class="leading-icon absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
        <span class="h-5 w-5 text-slate-400">
            <?php echo $leadingIcon; ?>

        </span>
    </div>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/vendor/form-components/partials/leading-addons.blade.php ENDPATH**/ ?>