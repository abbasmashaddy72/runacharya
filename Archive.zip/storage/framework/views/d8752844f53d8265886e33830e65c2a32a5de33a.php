<div>
    <div class="flex items-center mt-8">
        <h2 class="mr-auto text-lg font-medium">
            <?php if(getRouteAction() == 'create'): ?>
                <?php echo e(__('Create')); ?> <?php echo e($title); ?>

            <?php elseif(getRouteAction() == 'edit'): ?>
                <?php echo e(__('Edit')); ?> <?php echo e($title); ?>

            <?php elseif(getRouteAction() == 'show'): ?>
                <?php echo e(__('Show')); ?> <?php echo e($title); ?>

            <?php else: ?>
                <?php echo e($title); ?>

            <?php endif; ?>
        </h2>

        <?php if(Route::currentRouteName() != 'dashboard' && isset($top_right_button)): ?>
            <div class="flex w-full mt-4 sm:w-auto sm:mt-0">
                <?php echo e($top_right_button); ?>

            </div>
        <?php endif; ?>
    </div>

    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/components/backend/content.blade.php ENDPATH**/ ?>