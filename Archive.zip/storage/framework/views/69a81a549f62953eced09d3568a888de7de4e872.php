<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo e($dark_mode ? 'dark' : ''); ?>">

<head>
    <?php echo e(Vite::useBuildDirectory('/frontendAssets')); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="<?php echo e(asset('dist/images/logo.svg')); ?>" rel="shortcut icon" type="image/svg+xml">

    <title>
        <?php if(\Route::currentRouteName() != 'homepage'): ?>
            <?php echo e($title . ' | ' ?? ''); ?>

        <?php endif; ?>
        <?php echo e(config('app.name', 'Laravel')); ?>

    </title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/frontend/app.scss', 'resources/js/frontend/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="text-base text-black font-nunito dark:text-white dark:bg-slate-900">

    <?php echo $__env->make('layouts.fePartials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo e($slot); ?>


    <?php echo $__env->make('layouts.fePartials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/layouts/front.blade.php ENDPATH**/ ?>