<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> <?php echo Breadcrumbs::render('about.index'); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

         <?php $__env->slot('header', null, []); ?> 
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                <?php echo e(__('About Us')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="py-12">
            <?php if (isset($component)) { $__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495 = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Form::resolve(['action' => ''.e(route('admin.about.update')).'','hasFiles' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Form::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Files\FileUpload::resolve(['name' => 'image','label' => 'Image'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Files\FileUpload::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <div>
                        <?php if($image): ?>
                            <span class="block w-20 h-20">
                                <img class="w-full rounded-full" src="<?php echo e(url('storage/' . $image)); ?>" />
                            </span>
                        <?php endif; ?>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f)): ?>
<?php $component = $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f; ?>
<?php unset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Video Url
                    <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'video','value' => ''.e($video).'','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Description
                    <?php if (isset($component)) { $__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Textarea::resolve(['name' => 'description','value' => ''.e($description).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e)): ?>
<?php $component = $__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e; ?>
<?php unset($__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Short Description
                    <?php if (isset($component)) { $__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Textarea::resolve(['name' => 'short_description','value' => ''.e($short_description).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e)): ?>
<?php $component = $__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e; ?>
<?php unset($__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

                <button type="submit" class="mr-2 shadow-md btn btn-primary"><?php echo e(__('Update')); ?></button>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495)): ?>
<?php $component = $__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495; ?>
<?php unset($__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/pages/backend/about/index.blade.php ENDPATH**/ ?>