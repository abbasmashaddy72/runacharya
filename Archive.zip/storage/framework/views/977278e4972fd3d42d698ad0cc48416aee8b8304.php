<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> <?php echo Breadcrumbs::render('homepage.index'); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

         <?php $__env->slot('header', null, []); ?> 
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                <?php echo e(__('Home Page')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="py-12">
            <?php if (isset($component)) { $__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495 = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Form::resolve(['action' => ''.e(route('admin.homepage.update')).'','hasFiles' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Form::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <div class="flex justify-around">
                    <?php if (isset($component)) { $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Files\FileUpload::resolve(['name' => 'hero_image','label' => 'Hero Image'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Files\FileUpload::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div>
                            <?php if($hero_image): ?>
                                <span class="block w-20 h-20">
                                    <img class="w-full rounded-full" src="<?php echo e(url('storage/' . $hero_image)); ?>" />
                                </span>
                            <?php endif; ?>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f)): ?>
<?php $component = $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f; ?>
<?php unset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Files\FileUpload::resolve(['name' => 'logo','label' => 'Logo'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Files\FileUpload::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div>
                            <?php if($logo): ?>
                                <span class="block w-20 h-20">
                                    <img class="w-full rounded-full" src="<?php echo e(url('storage/' . $logo)); ?>" />
                                </span>
                            <?php endif; ?>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f)): ?>
<?php $component = $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f; ?>
<?php unset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f); ?>
<?php endif; ?>
                </div>

                <p class="text-lg font-semibold leading-tight text-gray-800">Hero Feature 1</p>

                <div class="grid-cols-3 gap-2 sm:grid">
                    <?php if (isset($component)) { $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Files\FileUpload::resolve(['name' => 'hero_feature_icon_1','label' => 'Hero Feature Icon 1'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Files\FileUpload::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div>
                            <?php if($hero_feature_icon_1): ?>
                                <span class="block w-20 h-20">
                                    <img class="w-full rounded-full"
                                        src="<?php echo e(url('storage/' . $hero_feature_icon_1)); ?>" />
                                </span>
                            <?php endif; ?>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f)): ?>
<?php $component = $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f; ?>
<?php unset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Hero Feature Text 1
                        <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'hero_feature_text_1','value' => ''.e($hero_feature_text_1).'','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Hero Feature Url 1
                        <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'hero_feature_url_1','value' => ''.e($hero_feature_url_1).'','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>
                </div>

                <p class="text-lg font-semibold leading-tight text-gray-800">Hero Feature 2</p>

                <div class="grid-cols-3 gap-2 sm:grid">
                    <?php if (isset($component)) { $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Files\FileUpload::resolve(['name' => 'hero_feature_icon_2','label' => 'Hero Feature Icon 2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Files\FileUpload::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div>
                            <?php if($hero_feature_icon_2): ?>
                                <span class="block w-20 h-20">
                                    <img class="w-full rounded-full"
                                        src="<?php echo e(url('storage/' . $hero_feature_icon_2)); ?>" />
                                </span>
                            <?php endif; ?>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f)): ?>
<?php $component = $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f; ?>
<?php unset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Hero Feature Text 2
                        <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'hero_feature_text_2','value' => ''.e($hero_feature_text_2).'','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Hero Feature Url 2
                        <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'hero_feature_url_2','value' => ''.e($hero_feature_url_2).'','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>
                </div>

                <p class="text-lg font-semibold leading-tight text-gray-800">Hero Feature 3</p>

                <div class="grid-cols-3 gap-2 sm:grid">
                    <?php if (isset($component)) { $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Files\FileUpload::resolve(['name' => 'hero_feature_icon_3','label' => 'Hero Feature Icon 3'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Files\FileUpload::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div>
                            <?php if($hero_feature_icon_3): ?>
                                <span class="block w-20 h-20">
                                    <img class="w-full rounded-full"
                                        src="<?php echo e(url('storage/' . $hero_feature_icon_3)); ?>" />
                                </span>
                            <?php endif; ?>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f)): ?>
<?php $component = $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f; ?>
<?php unset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Hero Feature Text 3
                        <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'hero_feature_text_3','value' => ''.e($hero_feature_text_3).'','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Hero Feature Url 3
                        <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'hero_feature_url_3','value' => ''.e($hero_feature_url_3).'','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>
                </div>

                <button type="submit" class="mr-2 shadow-md btn btn-primary"><?php echo e(__('Update')); ?></button>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495)): ?>
<?php $component = $__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495; ?>
<?php unset($__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/pages/backend/homepage/index.blade.php ENDPATH**/ ?>