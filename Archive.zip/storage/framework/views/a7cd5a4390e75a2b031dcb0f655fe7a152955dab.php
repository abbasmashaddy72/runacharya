<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['formAction' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['formAction' => false]); ?>
<?php foreach (array_filter((['formAction' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
    <?php if($formAction): ?>
        <form wire:submit.prevent="<?php echo e($formAction); ?>">
    <?php endif; ?>

    <div class="p-4 bg-white border-b sm:px-6 sm:py-4 border-gray-150">
        <?php if(isset($title)): ?>
            <h3 class="text-lg font-medium leading-6 text-gray-900">
                <?php echo e($title); ?>

            </h3>
        <?php endif; ?>
    </div>

    <div class="px-4 bg-white sm:p-6">
        <div class="space-y-6">
            <?php echo e($content); ?>

        </div>
    </div>

    <div class="justify-between p-4 pb-5 bg-white sm:px-4 sm:flex">
        <button wire:click="$emit('closeModal')" class="btn btn-danger" type="button">Close Modal</button>
        <?php echo e($buttons); ?>

    </div>

    <?php if($formAction): ?>
        </form>
    <?php endif; ?>
</div>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/components/backend/modal.blade.php ENDPATH**/ ?>