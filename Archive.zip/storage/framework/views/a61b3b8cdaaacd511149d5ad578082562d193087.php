<form method="<?php echo e($spoofMethod ? 'POST' : $method); ?>"
      <?php if($action): ?>
          action="<?php echo e($action); ?>"
      <?php endif; ?>

     <?php if($hasFiles): ?>
         enctype="multipart/form-data"
     <?php endif; ?>

    <?php if(! $spellcheck): ?>
        spellcheck="false"
    <?php endif; ?>

     <?php echo e($attributes); ?>

>
    <?php if (! (in_array($method, ['HEAD', 'GET', 'OPTIONS'], true))): ?>
        <?php echo csrf_field(); ?>
    <?php endif; ?>

    <?php if($spoofMethod): ?>
        <?php echo method_field($method); ?>
    <?php endif; ?>

    <?php echo e($slot); ?>

</form>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/vendor/form-components/components/form.blade.php ENDPATH**/ ?>