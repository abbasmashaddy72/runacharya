<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modal','data' => ['formAction' => 'save']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['form-action' => 'save']); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php if($doctor_id): ?>
            Update
        <?php else: ?>
            Add
        <?php endif; ?>
        <?php echo e(__(' Doctor')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="grid-cols-3 gap-2 sm:grid">
            <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Name
                <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'name','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'name','label' => 'Name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Degree
                <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'degree','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'degree','label' => 'Degree']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Specialty
                <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'specialty','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'specialty','label' => 'Specialty']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Reg. No.
                <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'reg_no','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'reg_no','label' => 'Reg. No.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Files\FileUpload::resolve(['name' => 'image','label' => 'Image','displayUploadProgress' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Files\FileUpload::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'image']); ?>
                <div>
                    <?php if($image): ?>
                        <span class="block w-20 h-20">
                            <img class="w-full rounded-full"
                                src="<?php echo e($isUploaded ? $image->temporaryUrl() : url('storage/' . $image)); ?>" />
                        </span>
                    <?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f)): ?>
<?php $component = $__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f; ?>
<?php unset($__componentOriginal482b8c5dc68715fe07f637e9ebfd52767a43918f); ?>
<?php endif; ?>
            
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('buttons', null, []); ?> 
        <button class="btn btn-primary" type="submit">Save</button>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/livewire/backend/modals/doctors-modal.blade.php ENDPATH**/ ?>