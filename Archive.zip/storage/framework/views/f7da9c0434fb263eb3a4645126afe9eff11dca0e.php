<?php if($after ?? null): ?>
    <?php echo e($after); ?>

<?php elseif($trailingAddon): ?>
    <div class="trailing-addon absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
        <span class="text-slate-500 sm:text-sm sm:leading-5"><?php echo $trailingAddon; ?></span>
    </div>
<?php elseif($trailingIcon): ?>
    <div class="trailing-icon pr-3 flex items-center absolute inset-y-0 right-0">
        <span class="h-5 w-5 text-slate-400">
            <?php echo $trailingIcon; ?>

        </span>
    </div>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/vendor/form-components/partials/trailing-addons.blade.php ENDPATH**/ ?>