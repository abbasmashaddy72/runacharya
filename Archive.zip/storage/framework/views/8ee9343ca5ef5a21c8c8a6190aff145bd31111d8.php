<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo e($dark_mode ? 'dark' : ''); ?>">

<head>
    <?php echo e(Vite::useBuildDirectory('/backendAssets')); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="<?php echo e(asset('dist/images/logo.svg')); ?>" rel="shortcut icon" type="image/svg+xml">

    <title>
        <?php if(getRouteAction() == 'create'): ?>
            <?php echo e(__('Create') . ' ' . $title . ' | ' ?? ''); ?>

        <?php elseif(getRouteAction() == 'edit'): ?>
            <?php echo e(__('Edit') . ' ' . $title . ' | ' ?? ''); ?>

        <?php elseif(getRouteAction() == 'show'): ?>
            <?php echo e(__('Show') . ' ' . $title . ' | ' ?? ''); ?>

        <?php else: ?>
            <?php echo e($title . ' | ' ?? ''); ?>

        <?php endif; ?>
        <?php echo e(config('app.name', 'Laravel')); ?>

    </title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/backend/app.css', 'resources/js/backend/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="py-5">
    <?php if($agent->isMobile()): ?>
        <!-- BEGIN: Mobile Menu -->
        <?php echo $__env->make('layouts.bePartials.mobile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Mobile Menu -->
    <?php endif; ?>
    <div class="flex">
        <?php if(!$agent->isMobile() || $agent->isTablet()): ?>
            <!-- BEGIN: Side Menu -->
            <?php echo $__env->make('layouts.bePartials.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- END: Side Menu -->
        <?php endif; ?>
        <div class="content">
            <!-- BEGIN: Top Bar -->
            <?php echo $__env->make('layouts.bePartials.top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- END: Top Bar -->
            <?php echo e($slot); ?>

        </div>

    </div>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-ui-modal')->html();
} elseif ($_instance->childHasBeenRendered('ykpjtXZ')) {
    $componentId = $_instance->getRenderedChildComponentId('ykpjtXZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('ykpjtXZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ykpjtXZ');
} else {
    $response = \Livewire\Livewire::mount('livewire-ui-modal');
    $html = $response->html();
    $_instance->logRenderedChild('ykpjtXZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
</body>

</html>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/layouts/app.blade.php ENDPATH**/ ?>