<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('left'); ?>
        <img alt="Larvel Tailwind HTML Admin Template" class="w-1/2 -mt-16 -intro-x"
            src="<?php echo e(asset('dist/images/illustration.svg')); ?>">
        <div class="w-4/6 mt-10 text-4xl font-medium leading-tight text-white -intro-x">
            <?php echo e(__('A few more clicks to sign in to your account.')); ?></div>
        <div class="mt-5 text-lg text-white -intro-x text-opacity-70 dark:text-slate-400">
            <?php echo e(__('Manage your Hospitals/Clinics in one place')); ?></div>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('right'); ?>
        <h2 class="text-2xl font-bold text-center intro-x xl:text-3xl xl:text-left"><?php echo e(__('Sign In')); ?></h2>

        <div class="mt-2 text-center intro-x text-slate-400 xl:hidden">
            <?php echo e(__('A few more clicks to sign in to your account.')); ?><?php echo e(__('Manage your Hospitals/Clinics in one place')); ?>

        </div>

        <div class="mt-8 intro-x">

            <!-- Session Status -->
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth.session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <!-- Validation Errors -->
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.validation-errors','data' => ['class' => 'mb-4','errors' => $errors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth.validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495 = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Form::resolve(['action' => ''.e(route('login')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Form::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Email')); ?>

                    <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'email','type' => 'email'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('Email')).'','required' => true,'autofocus' => true,'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Password')); ?>

                    <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'password','type' => 'password'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('Password')).'','required' => true,'autocomplete' => 'current-password','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

                <div class="flex mt-4 text-xs intro-x text-slate-600 dark:text-slate-500 sm:text-sm">

                    <div class="flex items-center mr-auto">
                        <?php if (isset($component)) { $__componentOriginal254d4e8297737d06cbbe0440ad5a68730f78a1d0 = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Choice\Checkbox::resolve(['name' => 'remember','label' => ''.e(__('Remember me')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Choice\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'checkbox']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal254d4e8297737d06cbbe0440ad5a68730f78a1d0)): ?>
<?php $component = $__componentOriginal254d4e8297737d06cbbe0440ad5a68730f78a1d0; ?>
<?php unset($__componentOriginal254d4e8297737d06cbbe0440ad5a68730f78a1d0); ?>
<?php endif; ?>
                    </div>

                    <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot your password?')); ?></a>
                </div>

                <div class="mt-5 text-center intro-x xl:mt-8 xl:text-left">

                    <button class="w-full px-2 py-2 mr-auto align-top btn btn-primary xl:w-32 xl:mr-3" id="btn-login"
                        type="submit"><?php echo e(__('Sign In')); ?></button>

                    <a class="w-full px-2 py-2 mt-3 align-top btn btn-outline-secondary xl:w-32 xl:mt-0"
                        href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                </div>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495)): ?>
<?php $component = $__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495; ?>
<?php unset($__componentOriginal142a27c023b3153a9113050fabc3f16c3d2b8495); ?>
<?php endif; ?>
        </div>
    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/auth/login.blade.php ENDPATH**/ ?>