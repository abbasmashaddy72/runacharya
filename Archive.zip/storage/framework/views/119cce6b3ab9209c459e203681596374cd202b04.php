<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modal','data' => ['formAction' => 'save']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['form-action' => 'save']); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php if($doctor_id): ?>
            Update
        <?php else: ?>
            Add
        <?php endif; ?>
        <?php echo e(__(' Testimonial')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="grid">
            <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Select Department
                <?php if (isset($component)) { $__componentOriginal91df51b7864a11c17334db8b7a759c400233b2aa = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Select::resolve(['name' => 'doctor_id','options' => getKeyValues('Doctor', 'name', 'id')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'doctor_id','label' => 'Select Doctor']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91df51b7864a11c17334db8b7a759c400233b2aa)): ?>
<?php $component = $__componentOriginal91df51b7864a11c17334db8b7a759c400233b2aa; ?>
<?php unset($__componentOriginal91df51b7864a11c17334db8b7a759c400233b2aa); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Name
                <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'name','type' => 'text'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'name','label' => 'Name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Rating
                <?php if (isset($component)) { $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Input::resolve(['name' => 'name','type' => 'number'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'rating','label' => 'Rating','min' => '1','max' => '5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef)): ?>
<?php $component = $__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef; ?>
<?php unset($__componentOriginal8cec7f38c3c5946ab9a025a4f2c35dbdb96079ef); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Message
                <?php if (isset($component)) { $__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e = $component; } ?>
<?php $component = Rawilk\FormComponents\Components\Inputs\Textarea::resolve(['name' => 'message'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Rawilk\FormComponents\Components\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'message','label' => 'Message','rows' => '5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e)): ?>
<?php $component = $__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e; ?>
<?php unset($__componentOriginalc643a50c36f8e238b828d6a6e7c53156c45d3b9e); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b)): ?>
<?php $component = $__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b; ?>
<?php unset($__componentOriginal2e30a9d1fd63720c8709ff44f29963b9baec157b); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('buttons', null, []); ?> 
        <button class="btn btn-primary" type="submit">Save</button>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/livewire/backend/modals/testimonial-modal.blade.php ENDPATH**/ ?>