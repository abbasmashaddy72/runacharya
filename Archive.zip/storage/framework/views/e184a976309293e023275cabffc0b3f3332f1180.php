<div
    <?php if(isset($column['tooltip']['text'])): ?> title="<?php echo e($column['tooltip']['text']); ?>" <?php endif; ?>
    class="flex flex-col items-center h-full px-6 py-5 overflow-hidden text-xs font-medium tracking-wider text-left text-gray-500 uppercase align-top bg-blue-100 border-b border-gray-200 leading-4 space-y-2 focus:outline-none">
    <div><?php echo e(__('SELECT ALL')); ?></div>
    <div>
        <input
        type="checkbox"
        wire:click="toggleSelectAll"
        class="w-4 h-4 mt-1 text-blue-600 form-checkbox transition duration-150 ease-in-out"
        <?php if($this->results->total() === count($visibleSelected)): ?> checked <?php endif; ?>
        />
    </div>
</div>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/livewire/datatables/filters/checkbox.blade.php ENDPATH**/ ?>