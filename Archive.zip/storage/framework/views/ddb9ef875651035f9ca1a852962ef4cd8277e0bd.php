<div class="<?php echo e($getContainerClass()); ?>">
    <?php echo $__env->make('form-components::partials.leading-addons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <input
        <?php echo e($attributes->except('aria-describedby')->class($inputClass())); ?>

        <?php echo $ariaDescribedBy(); ?>

        <?php echo e($extraAttributes); ?>


        <?php if($name): ?> name="<?php echo e($name); ?>" <?php endif; ?>
        <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?>
        type="<?php echo e($type); ?>"

        <?php if(! is_null($value) && ! $hasBoundModel()): ?> value="<?php echo e($value); ?>" <?php endif; ?>

        <?php if($hasErrorsAndShow($name)): ?>
            aria-invalid="true"
        <?php endif; ?>
    />

    <?php echo $__env->make('form-components::partials.trailing-addons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/vendor/form-components/components/inputs/input.blade.php ENDPATH**/ ?>