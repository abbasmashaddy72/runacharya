<?php if($hasLabel($slot)): ?>
<label <?php if($for): ?> for="<?php echo e($for); ?>" <?php endif; ?> <?php echo e($attributes->class('form-label block text-sm font-medium leading-5 text-slate-700')); ?>

       <?php if($customSelectLabel): ?>
           x-data
           x-on:click="document.querySelector('[data-name=<?php echo e(\Illuminate\Support\Str::slug($for)); ?>]').focus()"
       <?php endif; ?>
>
    <?php if($slot->isEmpty()): ?>
        <?php echo e($fallback); ?>

    <?php else: ?>
        <?php echo e($slot); ?>

    <?php endif; ?>
</label>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/vendor/form-components/components/label.blade.php ENDPATH**/ ?>