<div class="<?php echo e($getContainerClass()); ?>">
    <?php echo $__env->make('form-components::partials.leading-addons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <textarea <?php if($name): ?> name="<?php echo e($name); ?>" <?php endif; ?>
              <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?>
              <?php echo $ariaDescribedBy(); ?>

              <?php echo e($extraAttributes); ?>

              <?php if($hasErrorsAndShow($name)): ?>
                  aria-invalid="true"
              <?php endif; ?>

              <?php echo $attributes->merge(['class' => $inputClass(), 'rows' => 3]); ?>

    ><?php if(! is_null($value) && ! $hasBoundModel()): ?><?php echo $value; ?><?php elseif($slot->isNotEmpty()): ?><?php echo $slot; ?><?php endif; ?></textarea>

    <?php echo $__env->make('form-components::partials.trailing-addons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/vendor/form-components/components/inputs/textarea.blade.php ENDPATH**/ ?>