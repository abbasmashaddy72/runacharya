<?php if(isset($column['width'])): ?>style="width:<?php echo e($column['width']); ?>;"<?php endif; ?>
<?php if(isset($column['minWidth'])): ?>style="min-width:<?php echo e($column['minWidth']); ?>;"<?php endif; ?>
<?php if(isset($column['maxWidth'])): ?>style="max-width:<?php echo e($column['maxWidth']); ?>;"<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/livewire/datatables/style-width.blade.php ENDPATH**/ ?>