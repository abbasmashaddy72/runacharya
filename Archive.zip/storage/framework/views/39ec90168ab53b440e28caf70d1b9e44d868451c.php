<div class="choice-container relative flex items-start">
    <div class="choice-input flex items-center h-5">
        <input <?php echo $attributes->class($type === 'checkbox' ? 'form-checkbox h-4 w-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500' : 'form-radio h-4 w-4 text-blue-600 border-slate-300 focus:ring-blue-500')->except('type'); ?>

               <?php if($name): ?> name="<?php echo e($name); ?>" <?php endif; ?>
               <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?>
               type="<?php echo e($type); ?>"
               <?php if($value): ?> value="<?php echo e($value); ?>" <?php endif; ?>
               <?php if($checked && ! $hasBoundModel()): ?> checked <?php endif; ?>
               <?php echo e($extraAttributes); ?>

               <?php echo $ariaDescribedBy(); ?>

               <?php if($hasErrorsAndShow($name)): ?>
                   aria-invalid="true"
               <?php endif; ?>
        />
    </div>

    <?php if(! $slot->isEmpty() || $label || $description): ?>
        <div class="choice-label ml-3 text-sm leading-5">
            <?php if(! $slot->isEmpty() || $label): ?>
                <label for="<?php echo e($id); ?>" class="font-medium text-slate-700">
                    <?php if($label): ?>
                        <?php echo e($label); ?>

                    <?php else: ?>
                        <?php echo e($slot); ?>

                    <?php endif; ?>
                </label>
            <?php endif; ?>

            <?php if($description): ?>
                <p class="choice-description text-slate-500"><?php echo e($description); ?></p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/vendor/form-components/components/choice/checkbox-or-radio.blade.php ENDPATH**/ ?>