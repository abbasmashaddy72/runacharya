<?php if (isset($component)) { $__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a = $component; } ?>
<?php $component = App\View\Components\FrontLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FrontLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="relative py-16 mt-3 bg-gray-50 dark:bg-slate-800 md:py-24">
        <div class="container mt-16 md:mt-24">
            <div class="grid md:grid-cols-1 grid-cols-1 items-center gap-[30px]">
                <div class="mt-8 lg:col-span-5 md:col-span-6 md:mt-0">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.book-form')->html();
} elseif ($_instance->childHasBeenRendered('Q7Z2r4K')) {
    $componentId = $_instance->getRenderedChildComponentId('Q7Z2r4K');
    $componentTag = $_instance->getRenderedChildComponentTagName('Q7Z2r4K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Q7Z2r4K');
} else {
    $response = \Livewire\Livewire::mount('frontend.book-form');
    $html = $response->html();
    $_instance->logRenderedChild('Q7Z2r4K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
        <!--end container-->
    </section>
    <!--end section-->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a)): ?>
<?php $component = $__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a; ?>
<?php unset($__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a); ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/pages/frontend/book_appointment.blade.php ENDPATH**/ ?>