<?php if (isset($component)) { $__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a = $component; } ?>
<?php $component = App\View\Components\FrontLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FrontLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="relative py-16 mt-3 bg-gray-50 dark:bg-slate-800 md:py-24">
        <div class="container mt-16 md:mt-24">
            <div class="grid grid-cols-1 pb-8 text-center">
                <h3 class="mt-4 mb-6 text-2xl font-medium leading-normal md:text-3xl md:leading-normal dark:text-white">
                    Gallery
                </h3>
            </div>
            <!--end grid-->
            <div class="flex flex-wrap">
                <!-- First Repeater -->
                <?php $__currentLoopData = $directories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section id=<?php echo e(strtolower(str_replace(' ', '_', pathinfo($path)['filename']))); ?>>
                        <h1 class="font-semibold text-gray-900 text-xl md:text-4xl text-left mb-16">
                            <?php echo e(preg_replace('/[0-9]+/', '', pathinfo($path)['filename'])); ?></h1>
                        <div class="flex flex-wrap -mx-4">
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-1 md:gap-2 mx-auto">
                                <?php $__currentLoopData = \File::files('storage/' . $path); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="w-full px-4 flex flex-col">
                                        <div class="mb-10 group wow fadeInUp border-gray-200 border-2 p-4 rounded-lg shadow-testimonial flex-1"
                                            data-wow-delay=".1s">
                                            <div class="rounded overflow-hidden mb-8">
                                                <a href="<?php echo e(asset(pathinfo($item)['dirname'] . '/' . pathinfo($item)['basename'])); ?>"
                                                    data-lightbox="<?php echo e(strtolower(str_replace(' ', '_', pathinfo($path)['filename']))); ?>">
                                                    <img loading="lazy" src="https://via.placeholder.com/310x224"
                                                        data-src="<?php echo e(asset(pathinfo($item)['dirname'] . '/' . pathinfo($item)['basename'])); ?>"
                                                        alt="<?php echo e(preg_replace('/[^A-Za-z0-9\-]/', ' ', pathinfo($item)['filename'])); ?>"
                                                        class="w-full transition group-hover:scale-125 group-hover:rotate-6 h-56 object-cover lazyload" />
                                                </a>
                                            </div>
                                            <div>
                                                <h3
                                                    class="font-semibold teloginxt-xl sm:text-2xl lg:text-xl xl:text-2xl mb-4 inline-block text-dark">
                                                    <?php echo e(preg_replace('/[^A-Za-z0-9\-]/', ' ', pathinfo($item)['filename'])); ?>

                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!--end grid-->
        </div>
        <!--end container-->
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
            if ("loading" in HTMLImageElement.prototype) {
                var images = document.querySelectorAll('img[loading="lazy"]');
                var sources = document.querySelectorAll("source[data-srcset]");
                sources.forEach(function(source) {
                    source.srcset = source.dataset.srcset;
                });
                images.forEach(function(img) {
                    img.src = img.dataset.src;
                });
            } else {
                var script = document.createElement("script");
                script.src = "https://cdnjs.cloudflare.com/ajax/libs/jquery.lazyload/1.9.1/jquery.lazyload.min.js";
                document.body.appendChild(script);
            }
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a)): ?>
<?php $component = $__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a; ?>
<?php unset($__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a); ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/pages/frontend/gallery.blade.php ENDPATH**/ ?>