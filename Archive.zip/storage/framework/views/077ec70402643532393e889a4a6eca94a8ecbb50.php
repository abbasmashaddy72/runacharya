<svg <?php echo e($attributes->merge(['class' => 'h-5 w-5 stroke-current'])); ?> fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
</svg>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/vendor/mediconesystems/livewire-datatables/src/../resources/views/icons/check-circle.blade.php ENDPATH**/ ?>