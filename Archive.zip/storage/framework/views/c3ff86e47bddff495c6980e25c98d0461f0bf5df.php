<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> <?php echo Breadcrumbs::render('services.index'); ?> <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

         <?php $__env->slot('title', null, []); ?> Service Department <?php $__env->endSlot(); ?>
         <?php $__env->slot('top_right_button', null, []); ?> 
            <button onclick="Livewire.emit('openModal', 'backend.modals.service-departments-modal')"
                class="mr-2 shadow-md btn btn-primary"><?php echo e(__('Add')); ?></button>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('header', null, []); ?> 
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                <?php echo e(__('Service-departments')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="py-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.tables.service-departments-table')->html();
} elseif ($_instance->childHasBeenRendered('meUOkft')) {
    $componentId = $_instance->getRenderedChildComponentId('meUOkft');
    $componentTag = $_instance->getRenderedChildComponentTagName('meUOkft');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('meUOkft');
} else {
    $response = \Livewire\Livewire::mount('backend.tables.service-departments-table');
    $html = $response->html();
    $_instance->logRenderedChild('meUOkft', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

         <?php $__env->slot('title', null, []); ?> Service List <?php $__env->endSlot(); ?>
         <?php $__env->slot('top_right_button', null, []); ?> 
            <button onclick="Livewire.emit('openModal', 'backend.modals.services-modal')"
                class="mr-2 shadow-md btn btn-primary"><?php echo e(__('Add')); ?></button>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('header', null, []); ?> 
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                <?php echo e(__('Services')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="py-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.tables.services-table')->html();
} elseif ($_instance->childHasBeenRendered('C3Bqg0w')) {
    $componentId = $_instance->getRenderedChildComponentId('C3Bqg0w');
    $componentTag = $_instance->getRenderedChildComponentTagName('C3Bqg0w');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('C3Bqg0w');
} else {
    $response = \Livewire\Livewire::mount('backend.tables.services-table');
    $html = $response->html();
    $_instance->logRenderedChild('C3Bqg0w', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/pages/backend/services/index.blade.php ENDPATH**/ ?>