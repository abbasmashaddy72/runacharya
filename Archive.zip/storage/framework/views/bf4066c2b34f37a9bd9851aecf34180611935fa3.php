<a href="<?php echo e(route('admin.dashboard')); ?>" <?php echo e($attributes->merge(['class' => 'flex '])); ?>>
    <img alt="<?php echo e(config('app.name', 'Laravel')); ?> Logo" class="w-6" src="<?php echo e(asset('dist/images/logo.svg')); ?>">
    <?php echo e($slot); ?>

</a>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/components/logo.blade.php ENDPATH**/ ?>