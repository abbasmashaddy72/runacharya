<nav class="side-nav">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['class' => 'items-center pt-4 pl-5 intro-x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'items-center pt-4 pl-5 intro-x']); ?>
        <span class="hidden ml-3 text-lg text-white xl:block">
            <?php echo e(config('app.name', 'Laravel')); ?>

        </span>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="my-6 side-nav__devider"></div>
    <ul>
        <?php $__currentLoopData = $side_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuKey => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($menu == 'devider'): ?>
                <li class="my-6 side-nav__devider"></li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e(isset($menu['route_name']) ? route($menu['route_name']) : 'javascript:;'); ?>"
                        class="<?php echo e($first_level_active_index == $menuKey ? 'side-menu side-menu--active' : 'side-menu'); ?>">
                        <div class="side-menu__icon">
                            <i data-feather="<?php echo e($menu['icon']); ?>"></i>
                        </div>
                        <div class="side-menu__title">
                            <?php echo e($menu['title']); ?>

                            <?php if(isset($menu['sub_menu'])): ?>
                                <div
                                    class="side-menu__sub-icon <?php echo e($first_level_active_index == $menuKey ? 'transform rotate-180' : ''); ?>">
                                    <i data-feather="chevron-down"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                    </a>
                    <?php if(isset($menu['sub_menu'])): ?>
                        <ul class="<?php echo e($first_level_active_index == $menuKey ? 'side-menu__sub-open' : ''); ?>">
                            <?php $__currentLoopData = $menu['sub_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenuKey => $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(isset($subMenu['route_name']) ? route($subMenu['route_name']) : 'javascript:;'); ?>"
                                        class="<?php echo e($second_level_active_index == $subMenuKey ? 'side-menu side-menu--active' : 'side-menu'); ?>">
                                        <div class="side-menu__icon">
                                            <i data-feather="activity"></i>
                                        </div>
                                        <div class="side-menu__title">
                                            <?php echo e($subMenu['title']); ?>

                                            <?php if(isset($subMenu['sub_menu'])): ?>
                                                <div
                                                    class="side-menu__sub-icon <?php echo e($second_level_active_index == $subMenuKey ? 'transform rotate-180' : ''); ?>">
                                                    <i data-feather="chevron-down"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </a>
                                    <?php if(isset($subMenu['sub_menu'])): ?>
                                        <ul
                                            class="<?php echo e($second_level_active_index == $subMenuKey ? 'side-menu__sub-open' : ''); ?>">
                                            <?php $__currentLoopData = $subMenu['sub_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastSubMenuKey => $lastSubMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(isset($lastSubMenu['route_name']) ? route($lastSubMenu['route_name']) : 'javascript:;'); ?>"
                                                        class="<?php echo e($third_level_active_index == $lastSubMenuKey ? 'side-menu side-menu--active' : 'side-menu'); ?>">
                                                        <div class="side-menu__icon">
                                                            <i data-feather="zap"></i>
                                                        </div>
                                                        <div class="side-menu__title"><?php echo e($lastSubMenu['title']); ?>

                                                        </div>
                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav>
<?php /**PATH /home/abbasmashaddy72/Documents/Sites/npc/resources/views/layouts/bePartials/side-menu.blade.php ENDPATH**/ ?>