<x-front-layout>
    <div class="container mt-16 md:mt-24">
        <div class="grid grid-cols-1 pb-8 text-center">
            <h3 class="mt-8 text-2xl font-medium leading-normal md:text-3xl md:leading-normal dark:text-white">
                Contact Us
            </h3>
        </div>
    </div>
    <x-frontend.contact-us />
</x-front-layout>
