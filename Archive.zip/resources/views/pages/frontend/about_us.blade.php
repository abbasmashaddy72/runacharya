<x-front-layout>
    <!-- FEATURES START -->
    <section class="relative py-16 mt-3 bg-gray-50 dark:bg-slate-800 md:py-24">
        <x-frontend.about />
    </section>
    <!--end section-->
    <!-- End Section-->
</x-front-layout>
